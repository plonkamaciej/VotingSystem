
/**
 * Model Class
 * <p>
 * Model class, contains single candidate attributes and methods to manipulate it
 *
 * @since 1.0
 * @author Maciej Płonka
 * @version 1.1
 */
package pl.polsl.lab1.votesystem.Model;