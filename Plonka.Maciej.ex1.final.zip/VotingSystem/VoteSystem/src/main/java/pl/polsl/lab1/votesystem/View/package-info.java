/**
 * View class
 * <p>
 * handles output of the program
 *
 * @since 1.0
 * @author Maciej Płonka
 * @version 1.1
 */

package pl.polsl.lab1.votesystem.View;