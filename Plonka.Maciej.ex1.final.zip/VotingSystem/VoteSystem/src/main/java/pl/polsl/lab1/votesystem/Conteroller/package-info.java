/**
 * Controller Class
 * <p>
 * Handle view and model
 *
 * @since 1.0
 * @author Maciej Płonka
 * @version 1.1
 */

package pl.polsl.lab1.votesystem.Conteroller;