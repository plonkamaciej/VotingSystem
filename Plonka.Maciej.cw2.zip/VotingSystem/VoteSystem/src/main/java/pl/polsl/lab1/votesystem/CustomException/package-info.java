/**
 * Exception classes
 * <p>
 * - incorrect file nam exception
 *
 * @since 1.0
 * @author Maciej Płonka
 * @version 1.1
 */
package pl.polsl.lab1.votesystem.CustomException;