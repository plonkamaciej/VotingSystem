/**
 * Main function
 * <p>
 * Handle all kind of user input, handle console args
 * and ask specifically for values when no args are provided
 *
 *
 * @since 1.0
 * @author Maciej Płonka
 * @version 1.1
 */
package pl.polsl.lab1.votesystem;