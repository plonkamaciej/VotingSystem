/**
 * File Manager and files
 * <p>
 * Contains all program files and class with Read and write methods
 *
 * @since 1.0
 * @author Maciej Płonka
 * @version 1.1
 */
package pl.polsl.lab1.votesystem.fileMenager;