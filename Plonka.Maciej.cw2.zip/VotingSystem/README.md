# VotingSystem
Use votingSystem.jar to run program     

     *  use -add to add cancidate to the voting list
     *  use -show to show candidate list
     *  use -showV to show list of all voters
     *  use -show to show list of all candidates
     *  use -v with -u to vote

java -jar VotingSystem.jar -u User1 -v 1